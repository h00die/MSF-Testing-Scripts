#!/bin/sh

# You can set JAVA_HOME and JAVA_OPTS variables:
# JAVA_HOME points to JVM
# JAVA_OPTS sets JVM options

JAVA_CMD=java
if [ ! -z "$JAVA_HOME" ] ; then 
  JAVA_CMD=$JAVA_HOME/bin/java
fi
CONF=conf
LIBS=lib/ccc_misc5-1.02.jar:lib/coloradoftp-1.26.jar:lib/commons-logging-1.1.jar:lib/gateway-1.02.jar:lib/hardfilesystem-1.05.jar:lib/impl3659-1.00.jar:lib/intellipack-1.13.jar:lib/log4j-1.2.9.jar:lib/spring-2.5.4.jar:lib/xmlfs-1.00.jar:
echo "$JAVA_CMD" $JAVA_OPTS -cp "$CONF:$LIBS" Launcher
"$JAVA_CMD" $JAVA_OPTS -cp "$CONF:$LIBS" Launcher
